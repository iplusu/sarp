#define MAX_ONE_HOP_NEIGHBORS        100
#define MAX_OTHER_NEIGHBORS          100

#define MAX_ONE_HOP_NEIGHBORS_MSG    8
#define MAX_TREE_DEPTH  20

enum {
  ROOT      = 0,
  INNER     = 1,
  LEAF      = 2,
  NO_TYPE   = 3
};

enum {
  DISCOVERY_MSG_TYPE    = 20,
  READY_MSG_TYPE        = 21,
  READY_ACK_MSG_TYPE    = 22,
  START_MSG             = 23
};


/*
typedef struct Trust_Rec_t {
  uint8_t action;
  uint8_t trust; // int representation of a decimal, to convert / 100.0
} Trust_Rec_t;
*/

/*
typedef struct data {
  uint8_t segment_id;
  uint8_t data;
}
*/
/* EXTERNAL, FOR USE WITH DISCVOERY MESSAGES */
typedef struct Neighbor_Rec_t {
  uint8_t node_id;
  uint8_t level;
  uint8_t parent_id;  // do we have distinct parents or do we dynamically allocate them ?
} Neighbor_Rec_t;

/* INTERNAL */
typedef struct Neighbor_Rec_withTrust_t {
  uint8_t node_id;
  uint8_t level;
  uint8_t parent_id;  // do we have distinct parents or do we dynamically allocate them ?
  uint8_t trustFP;
  uint8_t trustRH;
} Neighbor_Rec_withTrust_t;


typedef struct DiscoveryMsg {
  uint8_t src;
  uint8_t level;
  uint8_t parent_id;
  uint8_t num_neighbors;
  Neighbor_Rec_t neighbors[MAX_ONE_HOP_NEIGHBORS_MSG];
} DiscoveryMsg;


typedef struct ReadyMsg {
    uint8_t src;
    uint8_t dest;
    uint8_t parent;
    uint8_t num_children;
} ReadyMsg;


typedef struct ReportRequestMsg {
  uint8_t requestor;
  uint8_t segment_id;
} ReportRequestMsg;


typedef struct ReportResponseMsg {
  uint8_t responder;
  uint8_t segment_id;
  uint8_t packetsReceived;
  uint8_t packetsReceivedFrom;
  uint8_t packetsForwarded;
  uint8_t packetsForwardedTo;
} ReportResponseMsg;

typedef struct BaseReportRequestMsg {
  uint8_t requestor;
  uint8_t segment_id;
  uint8_t hopsRemaining;
  uint8_t route[MAX_TREE_DEPTH];
} BaseReportRequestMsg;


typedef struct BaseReportResponseMsg {
  uint8_t responder;
  uint8_t segment_id;
  uint8_t packetsReceived;
  uint8_t packetsReceivedFrom;
} BaseReportResponseMsg;

typedef struct StartMsg {
    uint8_t src;
} StartMsg;
